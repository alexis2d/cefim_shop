let total = 0;
let x = 0;
let y = 0;
let prixtab = [];
let valuestab = [];

function fSomme() { // fonction du calcul/affichage du total et sous-total

	//remise à zéro des compteurs
	x = 0;
	y = 0;

	let prix = document.querySelectorAll(".prix"); // récupère les prix
	prix.forEach((e) => {prixtab[x] = e.innerHTML, x++}); // implante les prix dans un tableau
	let values = document.querySelectorAll(".values"); // récupère les quantités
	values.forEach((i) => {valuestab[y] = i.value, y++}); // implante les quantités dans un tableau
	
	// conversion en int et calcul de chaque prix
	let prix1 = parseInt(prixtab[0]) * parseInt(valuestab[0]);
	let prix2 = parseInt(prixtab[1]) * parseInt(valuestab[1]);
	let prix3 = parseInt(prixtab[2]) * parseInt(valuestab[2]);
	let prix4 = parseInt(prixtab[3]) * parseInt(valuestab[3]);
	let prix5 = parseInt(prixtab[4]) * parseInt(valuestab[4]);
	let prix6 = parseInt(prixtab[5]) * parseInt(valuestab[5]);

	// mise à jour des sous-totaux
	document.querySelector(".soustotal1", 0).textContent = prix1;
	document.querySelector(".soustotal2", 1).textContent = prix2;
	document.querySelector(".soustotal3", 2).textContent = prix3;
	document.querySelector(".soustotal4", 3).textContent = prix4;
	document.querySelector(".soustotal5", 4).textContent = prix5;
	document.querySelector(".soustotal6", 5).textContent = prix6;

	//calcul et mise à jour du total
	let total = prix1 + prix2 + prix3 + prix4 + prix5 + prix6;
	document.querySelector(".prixtotal").textContent = total;
	console.log(valuestab);

	// changement de couleur en fonction du prix
	let texte = document.getElementById("textetotal"); 
	let texteE = document.getElementById("textetotalE"); 

	if (total < 50) {
		texte.setAttribute("style", "color:lightgreen");
		texteE.setAttribute("style", "color:lightgreen"); 
	}

	if (total >= 50 && total < 75) {
		texte.setAttribute("style", "color:orange");
		texteE.setAttribute("style", "color:orange"); 
	}

	if (total > 75) {
		texte.setAttribute("style", "color:red");
		texteE.setAttribute("style", "color:red");
	}

	// 2 carte sd 8 go -> 1 carte sd 16 go (l'entrée manuelle pose problème, en recherche de solution)
	if (values[0].value == 2) {
		values[0].value = 0;
		values[1].value = parseInt(values[1].value) + 1;
		fSomme();
	}

	// limiter la quantité totale à 15 (non fini)
	let q1 = parseInt(values[0].value);
	let q2 = parseInt(values[1].value);
	let q3 = parseInt(values[2].value);
	let q4 = parseInt(values[3].value);
	let q5 = parseInt(values[4].value);
	let q6 = parseInt(values[5].value);

	let qtotale = q1 + q2 + q3 + q4 + q5 + q6;
	
}

function fReset() { // fonction reset
	let values = document.querySelectorAll(".values");
	for (i=0; i<values.length; i++) {
		values[i].value = 0;
		fSomme();
	}
}

document.querySelector(".prixtotal").textContent = total;